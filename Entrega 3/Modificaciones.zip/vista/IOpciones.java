package vista;

public interface IOpciones {
	void mostrarOpciones();
}
