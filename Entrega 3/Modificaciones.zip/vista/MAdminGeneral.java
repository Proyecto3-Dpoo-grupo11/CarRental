package vista;

public class MAdminGeneral implements IOpciones{

	@Override
	public void mostrarOpciones() {
		// TODO Auto-generated method stub
		
	}

}
