package vista;

public class MAdminSede implements IOpciones{

	@Override
	public void mostrarOpciones() {
		// TODO Auto-generated method stub
		
	}

}
