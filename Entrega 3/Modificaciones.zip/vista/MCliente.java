package vista;

public class MCliente implements IOpciones {

	@Override
	public void mostrarOpciones() {
		// TODO Auto-generated method stub
		
	}

}
