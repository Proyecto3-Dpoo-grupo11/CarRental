package vista;

public class MEmpleado implements IOpciones{

	@Override
	public void mostrarOpciones() {
		// TODO Auto-generated method stub
		
	}

}
