package vista;

import javax.swing.*;
import java.awt.*;


public class PMenuOpciones extends JPanel {
    private static final long serialVersionUID = 1L;
    private IOpciones menu;
    private JLabel welcomeLabel;

    public PMenuOpciones() {
        setBackground(Color.GRAY);

        // Agregar un mensaje de bienvenida
        welcomeLabel = new JLabel("<html><div style='text-align: center;'>" +
                "Bienvenido a la empresa de alquiler.<br>" +
                "Por favor, inicie sesión.</div></html>");
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        add(welcomeLabel);
    }

    public void setMenu(IOpciones menu) {
        this.menu = menu;
    }

    public void mostrarOpciones() {
        if (menu != null) {
            // Si deseas cambiar el mensaje después de iniciar sesión, puedes hacerlo aquí.
            welcomeLabel.setText("Mensaje personalizado después del inicio de sesión.");
            menu.mostrarOpciones();
        }
    }
}
